from flask import Flask, request, jsonify
import os
import sys

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from model_manager import ModelManager
from text_preprocessor import get_preprocessor

app = Flask(__name__)

# 初始化模型管理器
model_dir = os.environ.get("MODEL_DIR", os.path.join(os.path.dirname(__file__), "models"))
model_manager = ModelManager(model_dir=model_dir)

# 初始化预处理器
preprocessor = get_preprocessor()

@app.route("/")
def index():
    return jsonify({
        "message": "主题分析模型API",
        "version": "1.0.0",
        "endpoints": [
            "/api/analyze - 分析文本主题",
            "/api/health - 健康检查"
        ]
    })

@app.route("/api/health")
def health_check():
    return jsonify({
        "status": "healthy",
        "models_loaded": model_manager.models_loaded
    })

@app.route("/api/analyze", methods=["POST"])
def analyze():
    try:
        data = request.json
        if not data or "text" not in data:
            return jsonify({
                "error": "缺少text参数"
            }), 400
        
        text = data["text"]
        
        # 预处理文本
        preprocessed_text = preprocessor.preprocess(text)
        
        # 分析主题
        result = model_manager.analyze_theme(text)
        
        return jsonify({
            "success": True,
            "result": result
        })
        
    except Exception as e:
        app.logger.error(f"分析失败: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", 5000))
    
    app.run(host=host, port=port, debug=True)
