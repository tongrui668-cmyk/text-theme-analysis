# 模型部署说明

## 部署步骤

1. **准备环境**
   ```bash
   # 创建虚拟环境
   python3 -m venv venv
   
   # 激活虚拟环境
   # Windows
   venv\Scripts\activate
   # Linux/Mac
   source venv/bin/activate
   
   # 安装依赖
   pip install -r requirements.txt
   ```

2. **启动服务**
   ```bash
   # 开发环境
   python app.py
   
   # 生产环境
   gunicorn -w 4 -b 0.0.0.0:5000 app:app
   ```

3. **测试API**
   ```bash
   # 发送测试请求
   curl -X POST http://localhost:5000/api/analyze      -H "Content-Type: application/json"      -d '{"text": "这个APP很好用，推荐给大家"}'
   ```

## 目录结构

```
deployment/
├── models/              # 模型文件
├── src/                 # 源代码
├── app.py               # Flask应用
├── requirements.txt     # 依赖文件
└── DEPLOYMENT.md        # 部署说明
```

## 环境变量

| 变量名 | 默认值 | 描述 |
|-------|-------|------|
| FLASK_ENV | development | 运行环境 |
| FLASK_APP | app.py | 应用入口 |
| MODEL_DIR | ./models | 模型文件目录 |
| PORT | 5000 | 服务端口 |
| HOST | 0.0.0.0 | 服务主机 |
